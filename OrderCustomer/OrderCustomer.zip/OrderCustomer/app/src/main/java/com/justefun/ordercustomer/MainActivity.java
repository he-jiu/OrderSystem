package com.justefun.ordercustomer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import com.kymjs.rxvolley.RxVolley;
import com.kymjs.rxvolley.client.HttpCallback;
import com.kymjs.rxvolley.http.VolleyError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView dish_list;
    private List<DishData> mList = new ArrayList<>();

    private List<Integer> orderidlist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //去掉bar上方的阴影
//        getSupportActionBar().setElevation(0);
        setContentView(R.layout.dishprint);
        // initdishfagment();

        initdata();
        findView();
    }

    private void initdata() {


        String url = "http://47.107.79.142:6618/Myorder/ListMyorder";
        new RxVolley.Builder()
                .url(url)
                .httpMethod(RxVolley.Method.GET) //default GET or POST/PUT/DELETE/HEAD/OPTIONS/TRACE/PATCH
                .cacheTime(0) //default: get 5min, post 0min
                .contentType(RxVolley.ContentType.FORM)//default FORM or JSON
                .shouldCache(false) //default: get true, post false
                .callback(new HttpCallback() {
                    @Override
                    public void onSuccess(String t) {
                        try {
                            L.i("yyyyxx");
                            JSONArray jsonList = new JSONArray(t);
                            for (int i = 0; i < jsonList.length(); i++) {
                                JSONObject json = (JSONObject) jsonList.get(i);
                                int orderid;
                                String tablenum;

                                tablenum = json.getString("tablenumber");
                                if (tablenum.charAt(0) == '0') {//厨师未做订单
                                    orderid = Integer.parseInt(json.getString("orderid"));
                                    orderidlist.add(orderid);
                                    L.i("yyyy"+orderid);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        int ii;
                        for (int i = 0; i < orderidlist.size(); i++) {
                            ii = orderidlist.get(i);
                            L.i("yyyy000"+ii);
                            //解析接口
                            String url = "http://47.107.79.142:6618/Orderdetail/ListOrderdetailByid?orderid=" + ii;
                            final int finalIi = ii;
                            new RxVolley.Builder()
                                    .url(url)
                                    .httpMethod(RxVolley.Method.GET) //default GET or POST/PUT/DELETE/HEAD/OPTIONS/TRACE/PATCH
                                    .cacheTime(0) //default: get 5min, post 0min
                                    .contentType(RxVolley.ContentType.FORM)//default FORM or JSON
                                    .shouldCache(false) //default: get true, post false
                                    .callback(new HttpCallback() {
                                        @Override
                                        public void onSuccess(String t) {
                                            L.i("yyyy1111"+t);
                                            try {

                                                JSONArray jsonList = new JSONArray(t);
                                                for (int i = 0; i < jsonList.length(); i++) {
                                                    JSONObject json = (JSONObject) jsonList.get(i);

                                                    //L.i("yyyy4445" + json.getString("name"));

                                                    DishData data = new DishData();
                                                    data.setDishName(json.getString("name"));
                                                    data.setDishNum(Integer.parseInt(json.getString("count")));
                                                  //  data.setOrderID(1);
                                                    data.setOrderID(finalIi);

                                                  //  L.i("yyyy4444" + data.getDishName());
                                                    //Log.i("yyyy","yyyy"+data.getDishName());
                                                    mList.add(data);
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                            DishAdapter adapter = new DishAdapter(MainActivity.this, mList);
                                            dish_list.setAdapter(adapter);
                                        }
                                    }).encoding("UTF-8") //default
                                    .doTask();
                        }
                    }

                    @Override
                    public void onFailure(VolleyError error) {
                        super.onFailure(error);
                        L.i("yyyyx0"+error);
                    }
                }).encoding("UTF-8") //default
                .doTask();
    }

        /*for (int i = 0; i < 5; i++) {
            DishData data = new DishData();
            data.setDishName("样例菜品" + i);
            data.setDishNum(0);
            data.setOrderID(1);
            mList.add(data);
        }*/

    private void findView() {
        dish_list = findViewById(R.id.dishprint_list);

        //DishAdapter adapter = new DishAdapter(this, mList);
        //dish_list.setAdapter(adapter);
    }



}
